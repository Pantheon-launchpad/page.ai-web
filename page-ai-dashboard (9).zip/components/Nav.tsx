"use client";

import { useState } from "react";
import SignalMark from "./SignalMark";
import ThemeToggle from "@/components/theme/ThemeToggle";

const links = [
  { href: "#features", label: "Features" },
  { href: "#how-it-works", label: "How it works" },
  { href: "#pricing", label: "Pricing" },
  { href: "#faq", label: "FAQ" },
];

export default function Nav() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5 md:px-10">
        <div className="flex items-center gap-4 rounded-full border border-ink/10 bg-surface-1 py-2 pl-4 pr-5 backdrop-blur-xl md:hidden">
          <a href="#top" className="flex items-center gap-2 font-display text-[1.05rem] font-semibold text-ink">
            <SignalMark animated />
            Page.AI
          </a>
        </div>

        <a href="#top" className="hidden items-center gap-2.5 font-display text-lg font-semibold text-ink md:flex">
          <SignalMark animated />
          Page.AI
        </a>

        <div className="hidden items-center gap-8 rounded-full border border-ink/10 bg-surface-1 px-7 py-3 font-mono text-[13px] uppercase tracking-wide text-ink-soft backdrop-blur-xl md:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="nav-link transition-colors hover:text-signal">
              {l.label}
            </a>
          ))}
        </div>

        <div className="hidden items-center gap-4 md:flex">
          <ThemeToggle />
          <a href="/login" className="text-sm font-medium text-ink-soft transition-colors hover:text-ink">
            Log in
          </a>
          <a
            href="/signup"
            className="inline-flex items-center rounded-full bg-cta px-5 py-2.5 text-sm font-medium text-cta-text transition-transform hover:-translate-y-0.5 hover:bg-signal-deep"
          >
            Get the app
          </a>
        </div>

        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle />
          <button
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
            aria-expanded={open}
            className="flex h-11 w-11 items-center justify-center rounded-full border border-ink/10 bg-surface-1 backdrop-blur-xl"
          >
            <span className="relative block h-3 w-4">
              <span
                className={`absolute left-0 top-0 h-[1.5px] w-4 bg-ink transition-transform ${open ? "translate-y-[5px] rotate-45" : ""}`}
              />
              <span
                className={`absolute left-0 bottom-0 h-[1.5px] w-4 bg-ink transition-transform ${open ? "-translate-y-[5px] -rotate-45" : ""}`}
              />
            </span>
          </button>
        </div>
      </nav>

      {open && (
        <div className="mx-6 mb-4 flex flex-col gap-1 rounded-2xl border border-ink/10 bg-surface-1 p-4 font-mono text-sm uppercase tracking-wide text-ink-soft backdrop-blur-xl md:hidden">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2.5 transition-colors hover:bg-signal-soft hover:text-signal-deep"
            >
              {l.label}
            </a>
          ))}
          <a
            href="/login"
            onClick={() => setOpen(false)}
            className="rounded-lg px-3 py-2.5 text-center normal-case tracking-normal transition-colors hover:bg-signal-soft hover:text-signal-deep"
          >
            Log in
          </a>
          <a
            href="/signup"
            onClick={() => setOpen(false)}
            className="mt-1 rounded-lg bg-cta px-3 py-2.5 text-center normal-case tracking-normal text-cta-text"
          >
            Get the app
          </a>
        </div>
      )}
    </header>
  );
}
